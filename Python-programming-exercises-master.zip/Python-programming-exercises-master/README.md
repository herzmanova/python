# Python-programming-exercises

100+ Python challenge programming exercises.

## 100+ Python Projects Challenge 

https://github.com/zhiwehu/100_plus_Python_Projects_Challenge

## A simple Python online IDE run in browser.

Hey guys I just made a simple Python online IDE run in browser : https://github.com/zhiwehu/react-python-ide. It's free and opensource. Feel free to let me know if you have any issues.

## Python comic

Hey guys I just created a comic for learning Python if you like you could see it from here: https://zhixinfuture.com
For now I just use Chinese if you like I could use English as well.

![Python Comic](https://github.com/zhiwehu/Python-programming-exercises/blob/master/comic.png?raw=true)
